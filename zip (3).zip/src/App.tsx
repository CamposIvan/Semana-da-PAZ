import React, { useState, useEffect } from 'react';
import { anosIniciais, anosFinais, GradePlan } from './data';
import { 
  Calendar, CheckCircle2, ChevronRight, Target, 
  Users, BookOpen, PenTool, LayoutTemplate, 
  ArrowRight, ShieldCheck, FileCheck, Menu, X, Lightbulb, ChevronDown, ChevronUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type PlanWithCategory = GradePlan & { category: 'AI' | 'AF' };

export default function App() {
  const allPlans: PlanWithCategory[] = [ // merging into one list for sleek sidebar
    ...anosIniciais.map(p => ({ ...p, category: 'AI' as const })),
    ...anosFinais.map(p => ({ ...p, category: 'AF' as const }))
  ];

  const [selectedGrade, setSelectedGrade] = useState<PlanWithCategory>(allPlans[0]);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [expandedDay, setExpandedDay] = useState<number | null>(null);

  // Reset expanded day when selecting a new grade
  useEffect(() => {
    setExpandedDay(null);
  }, [selectedGrade]);

  return (
    <div className="flex flex-col min-h-screen font-sans text-slate-800 antialiased overflow-x-hidden bg-slate-50 relative">
      {/* Header Section */}
      <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between px-4 sm:px-8 py-4 bg-white border-b border-slate-200 shadow-sm z-30 sticky top-0">
        <div className="flex items-center gap-4 mb-4 sm:mb-0">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              PEI MARISA DE MELLO <span className="text-indigo-600 font-normal">| Semana da Não Violência 2026</span>
            </h1>
            <p className="text-xs text-slate-500 uppercase tracking-widest font-semibold mt-0.5">
              Resolução SEDUC nº 149/2026 • Cultura de paz nas escolas
            </p>
          </div>
        </div>
        <div className="flex gap-2 self-start sm:self-auto">
          <div className="flex items-center px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200 text-xs font-medium text-slate-600 shadow-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
            Cultura de Paz: Ativo
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex flex-col lg:flex-row flex-1 w-full max-w-screen-2xl mx-auto items-stretch relative">
        
        {/* Mobile Nav Toggle */}
        <div className="lg:hidden p-4 bg-white border-b border-slate-200 sticky top-[80px] sm:top-[73px] z-20">
          <button 
            onClick={() => setIsNavOpen(!isNavOpen)}
            className="flex items-center justify-between w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 font-medium active:bg-slate-100 transition-colors"
          >
            <span className="flex items-center gap-2 text-sm">
              {isNavOpen ? <X className="w-5 h-5 text-slate-500"/> : <Menu className="w-5 h-5 text-slate-500"/>} 
              <span className="font-bold text-slate-800">Segmento:</span>
            </span>
            <span className="text-sm font-bold text-indigo-600 truncate max-w-[180px] sm:max-w-[300px]">
              {selectedGrade.grade} • {selectedGrade.title}
            </span>
          </button>
        </div>

        {/* Sidebar Navigation */}
        {/* On mobile, this will overlay the content if open, or be hidden. On desktop, it's a normal flex item. */}
        {isNavOpen && (
          <div 
            className="fixed inset-0 bg-slate-800/20 z-20 lg:hidden backdrop-blur-sm"
            onClick={() => setIsNavOpen(false)}
          />
        )}
        <aside className={`
          ${isNavOpen ? 'translate-x-0' : '-translate-x-full'} 
          lg:translate-x-0
          fixed lg:static top-[148px] sm:top-[141px] lg:top-auto left-0 bottom-0 z-30
          w-[85vw] max-w-[320px] lg:w-72 
          bg-white/95 lg:bg-white backdrop-blur-md lg:backdrop-blur-none
          border-r border-slate-200 
          flex flex-col p-6 
          transition-transform duration-300 ease-in-out
          lg:min-h-[calc(100vh-130px)] shadow-2xl lg:shadow-none
          overflow-y-auto
        `}>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Segmentos de Ensino</p>
          <nav className="space-y-1.5 flex-1 pr-2">
            {allPlans.map((plan) => {
              const isActive = selectedGrade.id === plan.id;
              return (
                <button
                  key={plan.id}
                  onClick={() => {
                    setSelectedGrade(plan);
                    setIsNavOpen(false); // Close mobile menu on select
                  }}
                  className={`w-full flex items-center justify-between p-3 rounded-xl transition-all text-left border ${
                    isActive 
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-100 shadow-sm' 
                      : 'hover:bg-slate-100 lg:hover:bg-slate-50 border-transparent text-slate-600'
                  }`}
                >
                  <span className={`text-sm truncate mr-2 ${isActive ? 'font-bold' : 'font-medium'}`}>
                    <span className="opacity-80 font-normal">{plan.grade.split(' ')[0]}</span> {plan.title.substring(0, 18)}{plan.title.length > 18 ? '...' : ''}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md shrink-0 ${
                    isActive ? 'bg-indigo-200 text-indigo-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {plan.category}
                  </span>
                </button>
              );
            })}
          </nav>

          <div className="mt-6 pt-6 border-t border-slate-100 hidden lg:block">
            <div className="p-4 bg-slate-900 rounded-2xl text-white shadow-md">
              <p className="text-[10px] opacity-60 uppercase tracking-[0.2em] mb-1.5 font-bold">Diretriz</p>
              <p className="text-sm italic leading-relaxed text-slate-300">
                A transversalidade fortalece a convivência em todos os componentes.
              </p>
            </div>
          </div>
        </aside>

        {/* Detail Panel */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 flex flex-col gap-6 overflow-x-hidden min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedGrade.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col gap-6"
            >
              
              {/* Summary Card */}
              <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg overflow-hidden relative">
                {/* Decorative element */}
                <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-white opacity-5 rounded-full blur-2xl pointer-events-none"></div>
                
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex-1 pr-0 sm:pr-4">
                    <div className="text-indigo-200 text-xs font-bold uppercase tracking-widest mb-2 flex items-center gap-2 flex-wrap">
                      <span>{selectedGrade.category === 'AI' ? 'Anos Iniciais' : 'Anos Finais'}</span>
                      <span className="w-1 h-1 bg-indigo-300 rounded-full"></span>
                      <span>{selectedGrade.grade}</span>
                    </div>
                    <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold mb-4 tracking-tight leading-tight">
                      {selectedGrade.title}
                    </h2>
                    <p className="text-indigo-50 max-w-2xl text-sm sm:text-base leading-relaxed opacity-90 drop-shadow-sm font-medium">
                      <span className="font-bold opacity-100">Objetivo:</span> {selectedGrade.objective}
                    </p>
                  </div>
                  <div className="bg-white/10 p-3 sm:p-5 rounded-2xl backdrop-blur-md border border-white/20 shadow-inner hidden sm:flex flex-col items-center justify-center shrink-0">
                    <div className="text-2xl sm:text-3xl font-black leading-none drop-shadow-md">5</div>
                    <div className="text-[9px] sm:text-[10px] uppercase opacity-90 tracking-tighter sm:tracking-widest font-bold mt-1 text-center">Dias<br className="hidden lg:block"/> Letivos</div>
                  </div>
                </div>
              </div>

              {/* Components & Skills Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white border border-slate-200 shadow-sm rounded-2xl p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-3">
                    <BookOpen className="w-4 h-4 text-slate-400" />
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Componentes Curriculares</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedGrade.components.map((comp, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-slate-50 text-slate-700 hover:bg-slate-100 transition-colors cursor-default text-xs font-medium rounded-lg border border-slate-200">
                        {comp}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-white border border-slate-200 shadow-sm rounded-2xl p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-3">
                    <PenTool className="w-4 h-4 text-slate-400" />
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Habilidades Foco</h3>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed capitalize-first">
                    {selectedGrade.skills.charAt(0).toUpperCase() + selectedGrade.skills.slice(1)}
                  </p>
                </div>
              </div>

              {/* 5-Day Roadmap Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {selectedGrade.days.map((day, idx) => {
                  const isLast = idx === selectedGrade.days.length - 1;
                  const isExpanded = expandedDay === day.day;
                  
                  return (
                    <div 
                      key={day.day} 
                      onClick={() => setExpandedDay(isExpanded ? null : day.day)}
                      className={`flex flex-col bg-white rounded-2xl p-5 border shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5 cursor-pointer select-none ${
                        isLast 
                          ? 'border-indigo-200 ring-1 ring-indigo-600 ring-offset-2 ring-offset-slate-50 relative overflow-hidden' 
                          : isExpanded ? 'border-indigo-400 ring-1 ring-indigo-400 ring-offset-2 ring-offset-slate-50' : 'border-slate-200'
                      }`}
                    >
                      {isLast && <div className="absolute top-0 left-0 w-full h-1 bg-indigo-600"></div>}
                      
                      <div className="flex justify-between items-start mb-4">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shadow-sm ${
                          isLast || isExpanded ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}>
                          0{day.day}
                        </div>
                        <div className="bg-slate-50 p-1.5 rounded-full text-slate-400">
                          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                        </div>
                      </div>
                      
                      <h3 className={`text-sm font-bold mb-2 leading-tight ${isLast ? 'text-indigo-950' : 'text-slate-900'}`}>
                        {day.title}
                      </h3>
                      <p className="text-xs text-slate-500 leading-relaxed font-medium">
                        {day.description}
                      </p>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0, marginTop: 0 }}
                            animate={{ height: "auto", opacity: 1, marginTop: 16 }}
                            exit={{ height: 0, opacity: 0, marginTop: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden border-t border-slate-100 pt-3"
                          >
                            <div className="flex items-start gap-2 bg-indigo-50/50 p-3 rounded-xl border border-indigo-50">
                              <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                              <div className="text-xs font-medium text-slate-700 leading-relaxed">
                                {day.suggestion}
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>

              {/* Footer Branding & Final Product */}
              <div className="flex flex-col sm:flex-row gap-4 mt-2">
                <div className="flex-1 bg-white border border-slate-200 shadow-sm rounded-2xl p-5 sm:p-6 flex items-center gap-4 sm:gap-5 hover:shadow-md transition-shadow">
                  <div className="bg-emerald-50 text-emerald-600 w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border border-emerald-100">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                  </div>
                  <div>
                    <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 flex-wrap">Produto Final</p>
                    <p className="text-base sm:text-lg font-extrabold text-slate-900 leading-tight">
                      {selectedGrade.finalProduct.replace(/\.$/, '')}
                    </p>
                  </div>
                </div>
              </div>

            </motion.div>
          </AnimatePresence>
        </main>
      </div>
      
      {/* Footer */}
      <footer className="w-full border-t border-slate-200 bg-white py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500 font-medium text-center md:text-left">
            Desenvolvedor CGPG Ivan Sousa - Equipe MM 2026
          </p>
          <div className="text-xs text-slate-400 font-medium">
            PEI MARISA DE MELLO
          </div>
        </div>
      </footer>
    </div>
  );
}



export interface GradePlan {
  id: string;
  grade: string;
  title: string;
  objective: string;
  components: string[];
  skills: string;
  days: { day: number; title: string; description: string; suggestion: string }[];
  finalProduct: string;
}

export const anosIniciais: GradePlan[] = [
  {
    id: "1-ano",
    grade: "1º ano",
    title: "Cuidar de mim, do outro e da turma",
    objective: "desenvolver atitudes de acolhimento, escuta, respeito aos combinados e convivência gentil.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "Arte", "Educação Física"],
    skills: "oralidade, escuta, reconhecimento de emoções, comparação de atitudes, produção coletiva, coordenação motora, cooperação e respeito ao grupo.",
    days: [
      { day: 1, title: "Acolhida e escuta", description: "roda de conversa com perguntas simples sobre “o que é paz na escola”; leitura compartilhada de história curta; desenho livre sobre situações em que a turma se sente bem.", suggestion: "Organize as carteiras em círculo para garantir contato visual. Utilize um 'bastão de fala' (um objeto lúdico) para as crianças entenderem a vez de cada um." },
      { day: 2, title: "As palavras que ajudam", description: "classificação de palavras e atitudes em “faz bem” e “machuca”; formação de combinados da turma; registro com desenhos e escrita espontânea.", suggestion: "Prepare cartões com figuras e palavras coloridas. Use uma caixa verde para 'faz bem' e vermelha para 'machuca' para materializar o conceito." },
      { day: 3, title: "Meu corpo, minhas emoções", description: "conversa sobre sentimentos e sinais do corpo quando estamos felizes, bravos ou tristes; jogo de mímica das emoções; construção de um semáforo da convivência.", suggestion: "Faça a mímica junto com eles primeiramente. Para o semáforo, use cartolina e deixe visível na sala para consultas diárias." },
      { day: 4, title: "Brincar sem excluir", description: "circuito cooperativo na Educação Física, com desafios em dupla e em grupo; reflexão sobre esperar a vez, dividir materiais e ajudar o colega.", suggestion: "Em um espaço aberto, forme duplas misturando alunos que interagem pouco para estimular novas amizades." },
      { day: 5, title: "Mural da paz", description: "produção coletiva de cartaz com mãos coloridas, desenhos e palavras gentis; socialização para outra turma ou para a comunidade escolar.", suggestion: "Use tinta guache atóxica. Forre o chão com jornal. Envolva as famílias enviando fotos do mural concluído." }
    ],
    finalProduct: "mural “Nossa turma pratica a paz”."
  },
  {
    id: "2-ano",
    grade: "2º ano",
    title: "Palavras que constroem",
    objective: "perceber que a linguagem pode acolher, reparar e aproximar as pessoas.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "Arte", "Educação Física"],
    skills: "leitura de textos curtos, produção coletiva, organização de informações, interpretação de situações, empatia, argumentação inicial e criação artística.",
    days: [
      { day: 1, title: "Leitura inspiradora", description: "leitura de poema, parlenda ou texto curto sobre amizade e respeito; conversa sobre atitudes que fortalecem a convivência.", suggestion: "Escolha um texto com rimas fáceis. Peça para as crianças destacarem palavras carinhosas lidas no texto." },
      { day: 2, title: "Frases que ferem, frases que cuidam", description: "reescrita coletiva de falas agressivas em mensagens respeitosas; ditado de frases pela turma.", suggestion: "Use a lousa para mostrar o 'Antes' e 'Depois' das frases. Guie para que eles mesmos sugiram as mudanças." },
      { day: 3, title: "Dados da turma", description: "levantamento simples de atitudes positivas observadas na sala; organização em tabela ou gráfico pictórico.", suggestion: "Construa o gráfico na lousa usando marcadores ou notas autoadesivas para que visualizem a quantidade de boas atitudes." },
      { day: 4, title: "Arte da gentileza", description: "produção de cartões com mensagens de paz, colagem e ilustração; exposição no corredor da escola.", suggestion: "Disponibilize revistas para recorte, adesivos e canetinhas. Auxilie na estruturação de frases curtas para quem tem dificuldade na escrita." },
      { day: 5, title: "Jogo da escuta e do respeito", description: "brincadeiras cooperativas com regras de convivência; encerramento com partilha dos cartões produzidos.", suggestion: "Brincadeiras como 'telefone sem fio' adaptado com mensagens positivas, reforçando a importância da escuta atenta." }
    ],
    finalProduct: "varal de frases de convivência."
  },
  {
    id: "3-ano",
    grade: "3º ano",
    title: "Paz na escola e na comunidade",
    objective: "relacionar convivência escolar, responsabilidade coletiva e respeito ao espaço comum.",
    components: ["Língua Portuguesa", "História", "Geografia", "Matemática", "Arte", "Educação Física"],
    skills: "leitura e produção de textos curtos, observação do espaço vivido, registro de dados, comparação de situações, trabalho em equipe, criação visual e oralidade.",
    days: [
      { day: 1, title: "O que torna uma escola pacífica?", description: "leitura de texto informativo; roda de conversa sobre situações de convivência na escola e na comunidade.", suggestion: "Inicie sugerindo que fechem os olhos e imaginem um lugar tranquilo. Use isso como gancho para falar do ambiente escolar." },
      { day: 2, title: "Entrevista e registro", description: "os estudantes entrevistam colegas e funcionários sobre atitudes que ajudam a paz; organização das respostas em lista ou tabela.", suggestion: "Divida a turma em pequenos grupos e defina áreas da escola previamente para evitar aglomerações e garantir diversidade de entrevistados." },
      { day: 3, title: "Gráfico da convivência", description: "construção de gráfico simples com os dados levantados; interpretação coletiva dos resultados.", suggestion: "Utilize papel pardo ou quadriculado grande. Questione a eles: 'qual atitude foi mais citada?' e 'por que acham que foi essa?'." },
      { day: 4, title: "Carta à comunidade escolar", description: "produção de carta coletiva com sugestões para melhorar a convivência; revisão com apoio do professor.", suggestion: "Seja o escriba na lousa enquanto a turma dita as ideias, modelando a estrutura de uma carta formal simples." },
      { day: 5, title: "Mapa da paz", description: "criação de um mapa da escola marcando espaços de cuidado, acolhimento e melhoria; apresentação para outra turma.", suggestion: "Traga uma planta baixa simples da escola. Usem legendas coloridas (coração para lugar bom, estrela para lugar de melhoria)." }
    ],
    finalProduct: "“Mapa da paz” da escola."
  },
  {
    id: "4-ano",
    grade: "4º ano",
    title: "Convivência e responsabilidade coletiva",
    objective: "fortalecer atitudes de cooperação, mediação e responsabilidade diante dos conflitos do cotidiano escolar.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte", "Educação Física"],
    skills: "argumentação simples, leitura e produção textual, análise de dados, interpretação de situações sociais, organização de informações, cooperação e expressão artística.",
    days: [
      { day: 1, title: "Estudo de caso", description: "leitura de situações-problema sobre desentendimentos no recreio, em sala ou no trabalho em grupo; discussão orientada sobre alternativas sem violência.", suggestion: "Crie casos com personagens fictícios que remetam à realidade (ex: discussão pela bola). Peça que atuem (role-play) a solução." },
      { day: 2, title: "Pesquisa de clima da turma", description: "aplicação de enquete simples sobre convivência; tabulação dos resultados.", suggestion: "A enquete deve garantir o anonimato (ex: uso de uma urna fechada) garantindo que sejam honestos nas respostas." },
      { day: 3, title: "Soluções pacíficas", description: "produção de textos curtos com propostas para resolver conflitos; revisão coletiva das respostas.", suggestion: "Estimule a criação de um 'Pote de Soluções' para o mural, que servirá de consulta prática ao longo de todo o ano." },
      { day: 4, title: "Campanha visual", description: "produção de cartazes, tirinhas ou quadrinhos com mensagens sobre respeito, diálogo e cuidado.", suggestion: "Apresente exemplos de tirinhas cômicas e chame a atenção para os balões de diálogo. Peça foco nas expressões faciais amigáveis." },
      { day: 5, title: "Movimento cooperativo", description: "jogos em equipe na Educação Física com regras de ajuda mútua; culminância com apresentação da campanha.", suggestion: "Aplique brincadeiras de inversão (ex: corrida onde o time todo precisa passar junto de braços dados). A vitória só ocorre em conjunto." }
    ],
    finalProduct: "revista mural “Como nossa turma resolve conflitos”."
  },
  {
    id: "5-ano",
    grade: "5º ano",
    title: "Escolher a paz é agir",
    objective: "desenvolver postura crítica, solidária e protagonista diante de conflitos e situações de desrespeito.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte", "Educação Física"],
    skills: "leitura crítica, produção de opinião, interpretação e organização de dados, análise de problemas sociais, planejamento de ações, comunicação multimodal e trabalho colaborativo.",
    days: [
      { day: 1, title: "Escuta e diagnóstico", description: "roda de conversa sobre convivência na turma e na escola; levantamento de situações que favorecem ou prejudicam a paz.", suggestion: "Destaque o papel de quem assiste (o espectador) num conflito. Mostre como o silêncio frente a uma injustiça não colabora para a paz." },
      { day: 2, title: "Pesquisa com dados", description: "enquete com estudantes de outras turmas sobre respeito, bullying, exclusão e ajuda; organização dos resultados em tabela e gráfico.", suggestion: "Apoie na elaboração de um mini-roteiro para quando forem fazer as perguntas para estudantes de outras turmas." },
      { day: 3, title: "Produção de texto de opinião", description: "redação coletiva de um texto defendendo atitudes de paz na escola; revisão e reescrita com critérios simples.", suggestion: "Aproveite para ensinar conectivos lógicos (assim, contudo, por isso) montando a base do argumento no quadro." },
      { day: 4, title: "Campanha de conscientização", description: "criação de podcast, vídeo curto, cartaz ou história em quadrinhos sobre cultura de paz e respeito às diferenças.", suggestion: "Em turmas com facilidade tecnológica, use tablets para gravar áudios. Dê limite de tempo restrito (ex: 1 minuto) para focar na mensagem central." },
      { day: 5, title: "Socialização e compromisso", description: "apresentação dos produtos para a comunidade escolar; construção de um compromisso coletivo da turma.", suggestion: "Façam um grande cartaz como 'Contrato de Convivência' para que todos os estudantes deixem suas assinaturas no final." }
    ],
    finalProduct: "“Plano de ação da turma pela paz”."
  }
];

export const anosFinais: GradePlan[] = [
  {
    id: "6-ano",
    grade: "6º ANO",
    title: "Pertencimento e respeito nas relações",
    objective: "favorecer a adaptação aos anos finais, fortalecendo vínculos, respeito às diferenças e sentimento de pertencimento.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte", "Educação Física"],
    skills: "escuta ativa, argumentação inicial, leitura e interpretação de textos, organização de dados, reconhecimento de emoções, cooperação, trabalho em grupo.",
    days: [
      { day: 1, title: "Acolhida e escuta", description: "Roda de conversa: “Como está sendo minha experiência no 6º ano?”; Produção de nuvem de palavras (sentimentos e desafios).", suggestion: "Muitos vêm de rotinas diferentes no 5º ano. Acolha com empatia a dificuldade com cadernos difenciados e muitos professores." },
      { day: 2, title: "Identidade e convivência", description: "Produção de texto (relato pessoal ou carta): “A turma que eu quero construir”; Leitura e socialização de alguns textos.", suggestion: "Peça aos estudantes que escrevam focado não só no que querem, mas no que eles próprios se comprometem a fazer." },
      { day: 3, title: "Dados da convivência", description: "Aplicação de enquete sobre respeito, amizade e conflitos; Organização em tabela e gráfico (Matemática).", suggestion: "Se houver internet, ensine a montar as questões via Google Forms. Caso contrário, conte as mãos levantadas para pautas polêmicas em sala." },
      { day: 4, title: "Expressão e pertencimento", description: "Produção de mural coletivo (Arte): símbolos, frases e compromissos da turma; Dinâmica cooperativa na Educação Física.", suggestion: "Desenhem uma grande árvore, onde os alunos são as folhas, e os valores da Cultura de Paz são as raízes estruturantes." },
      { day: 5, title: "Pactos de convivência", description: "Construção coletiva de combinados da turma; Registro formal e socialização com a escola.", suggestion: "A lista de pactos precisa ser sucinta. Menos de 10 tópicos. Use linguagem positiva para que a regra pareça um acordo natural." }
    ],
    finalProduct: "Carta de compromisso da turma + mural colaborativo."
  },
  {
    id: "7-ano",
    grade: "7º ANO",
    title: "Diálogo e convivência (inclusive no digital)",
    objective: "desenvolver comunicação respeitosa e consciência sobre impactos das atitudes nas relações presenciais e virtuais.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte", "Educação Física"],
    skills: "argumentação, pensamento crítico, leitura de diferentes gêneros, análise de comportamentos, empatia, uso responsável da linguagem.",
    days: [
      { day: 1, title: "Provocação inicial", description: "Leitura de crônica ou notícia sobre conflitos entre jovens; Debate orientado.", suggestion: "Aborde o cyberbullying. Peça que reflitam se teriam a mesma atitude atrás de uma tela que têm pessoalmente." },
      { day: 2, title: "Comunicação que constrói ou destrói", description: "Análise de falas e mensagens (reais ou simuladas); Reescrita com base na comunicação respeitosa.", suggestion: "Introduza os fundamentos da Comunicação Não Violenta (fatos no lugar de julgamentos). Pratiquem transformações de frases irônicas." },
      { day: 3, title: "Pesquisa e dados", description: "Levantamento sobre convivência e possíveis situações de exclusão ou bullying; Construção de gráficos e análise.", suggestion: "Faça perguntas numéricas: 'quantas horas fica no celular?', cruzando com a frequência de pequenas infrações em sala." },
      { day: 4, title: "Produção midiática", description: "Criação de podcast, vídeo curto ou campanha digital sobre respeito; Trabalho em grupo.", suggestion: "Use os formatos populares das redes que eles assistem. Desafie-os a explicar o tema com humor e criatividade autênticos." },
      { day: 5, title: "Socialização e reflexão", description: "Apresentação das produções; Roda de conversa sobre responsabilidade nas relações.", suggestion: "Apague a luz, use um Datashow se possível. O ar de 'sessão de cinema' aumenta a importância de seus trabalhos." }
    ],
    finalProduct: "Campanha “Comunicar com respeito”."
  },
  {
    id: "8-ano",
    grade: "8º ANO",
    title: "Conflitos, escolhas e consequências",
    objective: "analisar conflitos sociais e interpessoais, desenvolvendo pensamento crítico e estratégias de mediação.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte"],
    skills: "argumentação estruturada, análise crítica, interpretação de dados, tomada de decisão, empatia, resolução de problemas.",
    days: [
      { day: 1, title: "Situações-problema", description: "Estudo de casos reais ou simulados de conflitos; Discussão em grupos sobre possíveis soluções.", suggestion: "Trabalhe dilemas em formato de júri. Divida as opiniões propositalmente e peça para cada grupo defender um lado usando de respeito e dados consistentes." },
      { day: 2, title: "Análise crítica", description: "Produção de texto de opinião: “Como resolver conflitos sem violência”; Revisão coletiva.", suggestion: "Foque na tese! A argumentação deve ter início, causa da divergência e conclusão para resolução mediada pacífica." },
      { day: 3, title: "Dados e realidade", description: "Análise de dados da escola (ou simulados) sobre convivência; Construção de gráficos e interpretação.", suggestion: "Neste ano é possível aprimorar a Matemática usando médias, modas e representações que correlacionem causa e efeito." },
      { day: 4, title: "Estratégias de mediação", description: "Simulações (role-play) de mediação de conflitos; Discussão sobre escuta e negociação.", suggestion: "Aprender a 'ouvir ativamente'. Faça duplas ensaiarem repetir (parafrasear) o que o outro relatou para validar a audição e empatia." },
      { day: 5, title: "Produção coletiva", description: "Elaboração de um guia prático de convivência e mediação.", suggestion: "Em vez de texto corrido, podem estruturar no formato de um folheto. Passos numerados dão ação às orientações do grupo." }
    ],
    finalProduct: "“Guia de mediação de conflitos da turma”."
  },
  {
    id: "9-ano",
    grade: "9º ANO",
    title: "Protagonismo juvenil e cultura de paz",
    objective: "desenvolver protagonismo, responsabilidade social e capacidade de intervenção na realidade escolar.",
    components: ["Língua Portuguesa", "Matemática", "Ciências", "História", "Geografia", "Arte", "Educação Física"],
    skills: "argumentação avançada, análise crítica de dados, planejamento, liderança, trabalho colaborativo, comunicação pública.",
    days: [
      { day: 1, title: "Diagnóstico da realidade", description: "Roda de conversa sobre convivência na escola; Levantamento de problemas e potencialidades.", suggestion: "Apliquem a matriz SWOT adaptada para a sala de aula: Forças (pontos fortes) e Fraquezas como ambiente base." },
      { day: 2, title: "Investigação com dados", description: "Pesquisa com estudantes da escola; Tabulação e análise (Matemática).", suggestion: "Com tabulação em mãos, eles devem ir além: identificar as raizes dos problemas em vez das consequências com alunos do fundão X frente, intervalos, etc." },
      { day: 3, title: "Produção argumentativa", description: "Elaboração de artigo de opinião ou manifesto sobre cultura de paz; Revisão e aprimoramento.", suggestion: "Trabalhem a linguagem marcante e urgente de um Manifesto Estudantil, algo passível até de tornar-se bandeira escolar." },
      { day: 4, title: "Planejamento de intervenção", description: "Criação de campanhas, projetos ou ações concretas para a escola (Ex: mediação entre pares, campanhas anti-bullying, acolhimento).", suggestion: "Metodologia prática exigida: Quem vai fazer? Como? Onde? Quando vai iniciar? Dará a base estruturada que uma equipe gestora aprovaria facilmente." },
      { day: 5, title: "Apresentação e protagonismo", description: "Apresentação das propostas para equipe gestora/professores; Construção de plano de ação real.", suggestion: "Construa o evento como um Pitch para convidados ou coordenadores. Eles devem argumentar e defender seu plano na prática." }
    ],
    finalProduct: "Plano de intervenção para melhoria da convivência escolar."
  }
];
